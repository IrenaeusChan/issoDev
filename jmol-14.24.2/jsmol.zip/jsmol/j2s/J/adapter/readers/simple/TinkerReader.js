Clazz.declarePackage ("J.adapter.readers.simple");
Clazz.load (["J.adapter.readers.simple.FoldingXyzReader"], "J.adapter.readers.simple.TinkerReader", null, function () {
c$ = Clazz.declareType (J.adapter.readers.simple, "TinkerReader", J.adapter.readers.simple.FoldingXyzReader);
});
